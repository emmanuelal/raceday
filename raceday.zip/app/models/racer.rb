require 'mongo'
require 'json'
require 'pp'
require 'byebug'

Mongo::Logger.logger.level = ::Logger::INFO
Mongo::Logger.logger.level = ::Logger::DEBUG


class Racer
  include ActiveModel::Model
  attr_accessor :id, :number, :first_name, :last_name, :gender, :group, :secs
  MONGO_URL='mongodb://localhost:27017'
  MONGO_DATABASE='raceday'
  RACE_COLLECTION='racers'

     
    def self.mongo_client
     url=ENV['MONGO_URL'] ||= MONGO_URL
     database=ENV['MONGO_DATABASE'] ||= MONGO_DATABASE 
     db = Mongo::Client.new(url)
     @@db=db.use(database)
    end

    def self.collection
       collection=ENV['RACE_COLLECTION'] ||= RACE_COLLECTION
       return mongo_client[collection]
    end
    

     # all method for gathering collection from the racer document 
    def self.all(prototype={}, sort={ :number => 1}, skip=0, limit=nil)
        result = collection.find(prototype)
        .sort(sort)
        .skip(skip)
        return limit.nil? ? result : result.limit(limit)
    end



    def initialize(params={})     
      @id=params[:_id].nil? ? params[:id] : params[:_id].to_s   
      @number=params[:number].to_i    
      @first_name=params[:first_name]   
      @last_name=params[:last_name]   
      @gender=params[:gender]   
      @group=params[:group]   
      @secs=params[:secs].to_i 
    end


    def self.find( id )    
        Rails.logger.debug{ "getting #{self}"}
        result = collection.find(_id: BSON::ObjectId(id))
        .projection(_id:true, number:true , first_name:true,
           last_name:true, gender:true ,group:true , secs:true).first
        return result.nil? ? nil : Racer.new(result)
    end

    def save 
        Rails.logger.debug {"saving #{self}"}
        result=self.class.collection.insert_one(_id:@id,number:@number,
          first_name:@first_name ,last_name:@last_name, gender:@gender , group:@group , secs:@secs )

        @id=result.inserted_id  # convert to string
        return @id.nil? ? nil : @id 
    end
  


    def update(updates)
     Rails.logger.debug {"updating #{self} with #{updates}"}
 
     @number = updates[:number].to_i
     @first_name = updates[:first_name]
     @last_name = updates[:last_name]
     @secs = updates[:secs].to_i
     @gender = updates[:gender]
     @group = updates[:group]
     
     updates.slice!(:number,:first_name,
                    :last_name, :gender, :group, :secs) if !updates.nil?
     self.class.collection.find(:_id=> BSON::ObjectId.from_string(@id))
    .update_one(updates)
    
   end

   def persisted?  
      !@id.nil? 
   end
 

    def destroy
      self.class.collection.find(:_id => BSON::ObjectId.from_string(@id)).delete_one
    end

    def created_at  
      nil 
    end 

    def updated_at  
      nil 
    end

    def self.paginate(params)  
        page=(params[:page] ||  1).to_i  
        limit=(params[:per_page]  ||  30).to_i   
        skip=(page-1)*limit
        racers=[]  
         #...find racer docs 
        all({} , {} , skip , limit).each do |doc|     
        racers  <<  Racer.new(doc) 
        end
           #...  
        total= all({} ,{} , 0, 1).count
        WillPaginate::Collection.create(page, limit,  total)  do  |pager|
        pager.replace(racers)   
      end 
    end
  end
